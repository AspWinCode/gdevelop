// @flow
import * as React from 'react';
import {
  type Profile,
  type LoginForm,
  type RegisterForm,
  type ForgotPasswordForm,
  type AuthError,
  type IdentityProvider,
} from '../Utils/GDevelopServices/Authentication';
import { type PreferencesValues } from '../MainFrame/Preferences/PreferencesContext';
import { type CloudProjectWithUserAccessInfo } from '../Utils/GDevelopServices/Project';
import { User as FirebaseUser } from 'firebase/auth';
import { type Badge, type Achievement } from '../Utils/GDevelopServices/Badge';
import {
  type Recommendation,
  type EditUserChanges,
} from '../Utils/GDevelopServices/User';
import { type Notification } from '../Utils/GDevelopServices/Notification';
import {
  type Limits,
  type Usages,
  type Subscription,
  type SubscriptionPlanPricingSystem,
  type UserEarningsBalance,
} from '../Utils/GDevelopServices/Usage';
import {
  type AssetShortHeader,
  type PrivateAssetPack,
  type PrivateGameTemplate,
  type Bundle,
} from '../Utils/GDevelopServices/Asset';
import { type Purchase } from '../Utils/GDevelopServices/Shop';
import { type ClaimedProductOptions } from './PurchaseClaimDialog';

export type AuthenticatedUser = {|
  authenticated: boolean,
  firebaseUser: ?FirebaseUser,
  profile: ?Profile,
  loginState: null | 'loggingIn' | 'done',
  creatingOrLoggingInAccount: boolean,
  badges: ?Array<Badge>,
  cloudProjects: ?Array<CloudProjectWithUserAccessInfo>,
  cloudProjectsFetchingErrorLabel: ?React.Node,
  receivedAssetPacks: ?Array<PrivateAssetPack>,
  receivedAssetShortHeaders: ?Array<AssetShortHeader>,
  receivedGameTemplates: ?Array<PrivateGameTemplate>,
  receivedBundles: ?Array<Bundle>,
  gameTemplatePurchases: ?Array<Purchase>,
  assetPackPurchases: ?Array<Purchase>,
  coursePurchases: ?Array<Purchase>,
  bundlePurchases: ?Array<Purchase>,
  recommendations: ?Array<Recommendation>,
  notifications: ?Array<Notification>,
  userEarningsBalance: ?UserEarningsBalance,
  limits: ?Limits,
  authenticationError: ?AuthError,
  usages: ?Usages,
  subscription: ?Subscription,
  subscriptionPricingSystem: ?SubscriptionPlanPricingSystem,
  onLogin: (form: LoginForm) => Promise<void>,
  onLoginWithProvider: (provider: IdentityProvider) => Promise<void>,
  onCancelLoginOrSignUp: () => void,
  onLogout: () => Promise<void>,
  onCreateAccount: (
    form: RegisterForm,
    preferences: PreferencesValues
  ) => Promise<void>,
  onEditProfile: (
    changes: EditUserChanges,
    preferences: PreferencesValues
  ) => Promise<void>,
  onResetPassword: ForgotPasswordForm => Promise<void>,
  onOpenLoginDialog: () => void,
  onOpenLoginWithPurchaseClaimDialog: (
    claimedProductOptions: ClaimedProductOptions
  ) => void,
  onOpenEditProfileDialog: () => void,
  onOpenChangeEmailDialog: () => void,
  onOpenCreateAccountDialog: () => void,
  onOpenCreateAccountWithPurchaseClaimDialog: (
    claimedProductOptions: ClaimedProductOptions
  ) => void,
  onOpenPurchaseClaimDialog: (
    claimedProductOptions: ClaimedProductOptions
  ) => void,
  claimedProductOptions: ?ClaimedProductOptions,
  onClosePurchaseClaimDialog: () => void,
  onBadgesChanged: () => Promise<void>,
  onCloudProjectsChanged: () => Promise<void>,
  onRefreshUserProfile: () => Promise<void>,
  onRefreshFirebaseProfile: () => Promise<void>,
  onRefreshSubscription: () => Promise<void>,
  onRefreshLimits: () => Promise<void>,
  onRefreshGameTemplatePurchases: () => Promise<void>,
  onRefreshAssetPackPurchases: () => Promise<void>,
  onRefreshCoursePurchases: () => Promise<void>,
  onRefreshBundlePurchases: () => Promise<void>,
  onRefreshEarningsBalance: () => Promise<void>,
  onRefreshNotifications: () => Promise<void>,
  onPurchaseSuccessful: () => Promise<void>,
  onSendEmailVerification: () => Promise<void>,
  onOpenEmailVerificationDialog: ({|
    sendEmailAutomatically: boolean,
    showSendEmailButton: boolean,
  |}) => void,
  onAcceptGameStatsEmail: (value: boolean) => Promise<void>,
  getAuthorizationHeader: () => Promise<string>,
  achievements: ?Array<Achievement>,
|};

export const authenticatedUserPropertiesLoadingState = {
  cloudProjects: null,
  receivedAssetPacks: null,
  receivedAssetShortHeaders: null,
  receivedGameTemplates: null,
  receivedBundles: null,
  badges: null,
  notifications: null,
};

export const initialAuthenticatedUser = {
  authenticated: false,
  firebaseUser: null,
  profile: null,
  loginState: null,
  creatingOrLoggingInAccount: false,
  cloudProjectsFetchingErrorLabel: null,
  gameTemplatePurchases: null,
  assetPackPurchases: null,
  coursePurchases: null,
  bundlePurchases: null,
  recommendations: null,
  subscription: null,
  subscriptionPricingSystem: null,
  usages: null,
  userEarningsBalance: null,
  limits: null,
  ...authenticatedUserPropertiesLoadingState,
  authenticationError: null,
  onLogin: async () => {},
  onLoginWithProvider: async () => {},
  onCancelLoginOrSignUp: () => {},
  onLogout: async () => {},
  onCreateAccount: async () => {},
  onEditProfile: async () => {},
  onResetPassword: async () => {},
  onOpenLoginDialog: () => {},
  onOpenLoginWithPurchaseClaimDialog: () => {},
  onOpenEditProfileDialog: () => {},
  onOpenChangeEmailDialog: () => {},
  onOpenCreateAccountDialog: () => {},
  onOpenCreateAccountWithPurchaseClaimDialog: () => {},
  onOpenPurchaseClaimDialog: () => {},
  claimedProductOptions: null,
  onClosePurchaseClaimDialog: () => {},
  onBadgesChanged: async () => {},
  onCloudProjectsChanged: async () => {},
  onRefreshUserProfile: async () => {},
  onRefreshFirebaseProfile: async () => {},
  onRefreshSubscription: async () => {},
  onRefreshLimits: async () => {},
  onRefreshGameTemplatePurchases: async () => {},
  onRefreshAssetPackPurchases: async () => {},
  onRefreshCoursePurchases: async () => {},
  onRefreshBundlePurchases: async () => {},
  onRefreshEarningsBalance: async () => {},
  onRefreshNotifications: async () => {},
  onPurchaseSuccessful: async () => {},
  onSendEmailVerification: async () => {},
  onOpenEmailVerificationDialog: () => {},
  onAcceptGameStatsEmail: async () => {},
  getAuthorizationHeader: () => Promise.reject(new Error('Unimplemented')),
  achievements: null,
};

export const fakeLocalProfile: Profile = {
  id: 'local-user',
  email: 'local@gdevelop.local',
  username: 'LocalUser',
  description: null,
  updatedAt: Date.now(),
  createdAt: Date.now(),
  getGameStatsEmail: false,
  getNewsletterEmail: false,
  appLanguage: null,
  isCreator: true,
  isPlayer: false,
  isEmailAutogenerated: true,
  donateLink: null,
  discordUsername: null,
};

export const fakeLocalUserAttributes = {
  authenticated: true,
  firebaseUser: null,
  profile: fakeLocalProfile,
  loginState: 'done',
  badges: [],
  cloudProjects: [],
  cloudProjectsFetchingErrorLabel: null,
  receivedAssetPacks: [],
  receivedAssetShortHeaders: [],
  receivedGameTemplates: [],
  receivedBundles: [],
  subscription: null,
  subscriptionPricingSystem: null,
  userEarningsBalance: null,
  usages: null,
  limits: null,
};

export const authenticatedUserLoggedOutAttributes = {
  authenticated: false,
  firebaseUser: null,
  profile: null,
  // A logged out user is not the same a user being loaded (which can be the case at startup).
  // Use this loginState to make sure this is understood by the app as a user logged out, and not loading.
  loginState: 'done',
  badges: null,
  cloudProjects: [], // Initialize to empty array to indicate that the loading is done.
  cloudProjectsFetchingErrorLabel: null,
  receivedAssetPacks: [], // Initialize to empty array to indicate that the loading is done.
  receivedAssetShortHeaders: [], // Initialize to empty array to indicate that the loading is done.
  receivedGameTemplates: [], // Initialize to empty array to indicate that the loading is done.
  receivedBundles: [], // Initialize to empty array to indicate that the loading is done.
  subscription: null,
  subscriptionPricingSystem: null,
  userEarningsBalance: null,
  usages: null,
  limits: null,
};

const AuthenticatedUserContext = React.createContext<AuthenticatedUser>(
  initialAuthenticatedUser
);

export default AuthenticatedUserContext;
